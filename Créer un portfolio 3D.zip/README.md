
  # Créer un portfolio 3D

  This is a code bundle for Créer un portfolio 3D. The original project is available at https://www.figma.com/design/tHNAmTuLMdyTS1N5YkQGVc/Cr%C3%A9er-un-portfolio-3D.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  